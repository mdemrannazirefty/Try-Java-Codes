
public class Start {
  public static void main(String[] args) {
     new LogInPage();
    // new ForgetPass();
    // new Signup();
    // new OderPage();
   // new AdminLogin();
    // new Profile("Test");
    // new Dashboard("Test");
   //  new UserdashBoard();
      
  }
}