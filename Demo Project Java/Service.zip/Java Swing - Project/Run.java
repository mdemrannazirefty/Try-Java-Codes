public class Run{
	
	@SuppressWarnings(/* "deprecation", */ "unchecked")
	//@SuppressWarnings("unchecked")
	public static void main(String []args){
	
	/* Home h1 = new Home();
	h1.setVisible(true); */
	
	Welcome w1 = new Welcome();
	w1.setVisible(true);
	
	
    /* Login f1 = new Login();
    f1.setVisible(true); */
	 
	 
	/* AdminLogin a1 = new AdminLogin();
	a1.setVisible(true);
	
	AdminPage ap1 = new AdminPage();
	ap1.setVisible(true);
	 */
	
	/* Signup s1 = new Signup();
	s1.setVisible(true); */
	
	}
	
}