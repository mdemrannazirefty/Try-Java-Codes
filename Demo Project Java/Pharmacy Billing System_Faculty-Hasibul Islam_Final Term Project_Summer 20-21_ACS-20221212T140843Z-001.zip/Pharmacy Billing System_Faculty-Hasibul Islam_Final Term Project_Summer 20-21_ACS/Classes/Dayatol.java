package Classes;
public class Dayatol extends Medicines{
	public Dayatol(String name,String genericName,String expiryDate,int price,int quantity,int tax,int discount){
		super(name,genericName,expiryDate,price,quantity,tax,discount);
	}
	
	public void showAll(){
		super.showAll();	
		
	}
}